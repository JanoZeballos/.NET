﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CuentaBancaria
{
    public class Cuenta
    {
        //Atributos miembros de la clase
        private decimal saldo; //Variable de instancia

        public string Nombre { get; set; } //Propiedad

        public decimal Balance
        {
            get
            {
                return saldo;
            }

            private set
            {
                if(value > 0.0m)
                {
                    saldo = value;
                }
            }
        }

        //Metodos (Constructor)

        public Cuenta(string prmNombreCliente, decimal prmSaldoInicial)
        {
            Nombre = prmNombreCliente;
            Balance = prmSaldoInicial;
        }

        public void Depositar(decimal prmMontoDeposito)
        {
            Balance += prmMontoDeposito;
        }

        public void Retirar(decimal prmMontoRetiro)
        {
            Balance -= prmMontoRetiro;
        }



    }
}
