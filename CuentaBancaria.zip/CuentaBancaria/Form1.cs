﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CuentaBancaria
{
    public partial class Form1 : Form
    {
        private Cuenta objCuenta; //Acceso global dentro de la clase Form1

        public Form1()
        {
            InitializeComponent();
        }

        //Refresca el saldo en pantalla
        private void refrescarSaldo()
        {
            lblsaldo.Text = String.Format("{0:0.00}", objCuenta.Balance);
            txtmonto.Text = "";
        }

        private void btncrear_Click(object sender, EventArgs e)
        {
            objCuenta = new Cuenta(txtcliente.Text, decimal.Parse(txtsaldoinicial.Text));
            if(objCuenta != null)
            {
                refrescarSaldo();
                groupBox1.Enabled = true;
            }
        }

        private void btndeposito_Click(object sender, EventArgs e)
        {
            objCuenta.Depositar(decimal.Parse(txtmonto.Text));
            refrescarSaldo();
        }

        private void btnretirar_Click(object sender, EventArgs e)
        { 
            if(decimal.Parse(txtmonto.Text) <= objCuenta.Balance)
            {
                objCuenta.Retirar(decimal.Parse(txtmonto.Text));
                refrescarSaldo();
            }
            else
            {
                MessageBox.Show("Saldo insuficiente");
            }
        }
    }
}
