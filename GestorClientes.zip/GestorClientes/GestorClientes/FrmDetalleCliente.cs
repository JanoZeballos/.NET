﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestorClientes
{
    public partial class FrmDetalleCliente : Form
    {

        private Cliente _modificacionCliente;

        public FrmDetalleCliente()
        {
            InitializeComponent();
        }

        public Cliente ModificadorCliente
        {
            get
            {
                return _modificacionCliente;
            }

            set
            {
                _modificacionCliente = value;
                bindingCliente.Add(_modificacionCliente);
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {

        }
    }
}
