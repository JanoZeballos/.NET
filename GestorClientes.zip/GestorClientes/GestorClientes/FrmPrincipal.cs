﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestorClientes
{
    public partial class FrmPrincipal : Form
    {

        private ClienteManager _clienteManager; 

        public FrmPrincipal()
        {
            InitializeComponent();
            _clienteManager = new ClienteManager();
        }

        private void Refrescar()
        {
            listClientes.Items.Clear();

            List<Cliente> clientesTodos = _clienteManager.ClientesTodos;

            foreach(Cliente elemento in clientesTodos)
            {
                ListViewItem item = listClientes.Items.Add(elemento.Nombre);
                item.SubItems.Add(elemento.Apellido);
                item.SubItems.Add(elemento.Direccion);
                item.SubItems.Add(elemento.FechaCreacion.ToString("dd/MM/yyyy HH:mm:ss"));
            }


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            FrmDetalleCliente FDetalle = new FrmDetalleCliente();

            FDetalle.ModificadorCliente = new Cliente();

            if(FDetalle.ShowDialog() == DialogResult.OK)
            {
                Cliente newCliente = FDetalle.ModificadorCliente;
                _clienteManager.AgregaCliente(newCliente.Nombre,newCliente.Apellido,newCliente.Direccion);
                Refrescar();
            }
            else
            {

            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if(listClientes.SelectedIndices.Count > 0)
            {
                Cliente editCliente = _clienteManager.ClientesTodos[listClientes.SelectedIndices[0]];

                FrmDetalleCliente FDetalle = new FrmDetalleCliente();

                FDetalle.ModificadorCliente = editCliente;

                FDetalle.ShowDialog();

                _clienteManager.EditarCliente(listClientes.SelectedIndices[0], FDetalle.ModificadorCliente);

                Refrescar();
            }
            else
            {
                MessageBox.Show("Debe seleccionar un Cliente");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(null,"Desea eliminar","Lo Juras",MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _clienteManager.EliminarCliente(listClientes.SelectedIndices[0]);
                Refrescar();
            }
        }

        private void btnClonar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(null, "Desea clonar el cliente", "Lo Juras", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _clienteManager.DuplicarCliente(listClientes.SelectedIndices[0]);
            }
        }
    }
}
