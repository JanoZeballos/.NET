﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestorClientes
{
    public class ClienteManager
    {
        private List<Cliente> _listClientes; //Almacenamiento

        public ClienteManager()
        {
            _listClientes = new List<Cliente>();
        }

        //Propiedad que devuelve todos los Clientes
        public List<Cliente> ClientesTodos
        {
            get
            {
                return _listClientes;
            }
        }

        public void AgregaCliente(string prmNombre, string prmApellido, string prmDireccion)
        {
            //Agregamos valores a nuevoCliente
            Cliente nuevoCliente = new Cliente()
            {
                Nombre = prmNombre,
                Apellido = prmApellido,
                Direccion = prmDireccion
            };

            _listClientes.Add(nuevoCliente); //Agregamos a la lista

        }

        public void EditarCliente(int prmPosicion, Cliente prmObjeCliente)
        {
            _listClientes[prmPosicion] = prmObjeCliente;
            //{
            //    Nombre = prmObjeCliente.Nombre,
            //    Apellido = prmObjeCliente.Apellido,
            //    Direccion = prmObjeCliente.Direccion
            //};
        }

        public void EliminarCliente(int prmPosicion)
        {
            _listClientes.RemoveAt(prmPosicion); //Eliminar posicion en la lista
        }

        public void DuplicarCliente(int prmPosicion)
        {
            Cliente duplicadoCliente = _listClientes[prmPosicion];
            AgregaCliente("Copia de: " + duplicadoCliente.Nombre, duplicadoCliente.Apellido, duplicadoCliente.Direccion);
        }


    }
}
