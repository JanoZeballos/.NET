﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculatorplus
{
    public partial class Formularioprincipal : Form
    {
        string _valoresMarcados;

        public Formularioprincipal()
        {
            InitializeComponent();
        }

        private void CapturaValor(string preValor){
            _valoresMarcados += preValor;
            textBox1.Text = preValor;
        }

        private void btn1(object sender,EventArgs e){
            CapturaValor("1");
        }

        private void btn2(object sender, EventArgs e)
        {
            CapturaValor("2");
        }

        private void btn3(object sender, EventArgs e)
        {
            CapturaValor("3");
        }

        private void btn4(object sender, EventArgs e)
        {
            CapturaValor("4");
        }

        private void btn5(object sender, EventArgs e)
        {
            CapturaValor("5");
        }

        private void btn6(object sender, EventArgs e)
        {
            CapturaValor("6");
        }

        private void btn7(object sender, EventArgs e)
        {
            CapturaValor("7");
        }

        private void btn8(object sender, EventArgs e)
        {
            CapturaValor("8");
        }

        private void btn9(object sender, EventArgs e)
        {
            CapturaValor("9");
        }
    }
}
