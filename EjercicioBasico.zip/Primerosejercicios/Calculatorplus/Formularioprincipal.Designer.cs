﻿namespace Calculatorplus
{
    partial class Formularioprincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btnc = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnpunto = new System.Windows.Forms.Button();
            this.btnigual = new System.Windows.Forms.Button();
            this.btnmenos = new System.Windows.Forms.Button();
            this.btnmas = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnpor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(12, 210);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(58, 37);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(75, 210);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(58, 37);
            this.btn2.TabIndex = 1;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(139, 210);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(58, 37);
            this.btn3.TabIndex = 1;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(11, 167);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(58, 37);
            this.btn4.TabIndex = 3;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(75, 167);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(58, 37);
            this.btn5.TabIndex = 4;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(139, 167);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(58, 37);
            this.btn6.TabIndex = 5;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(11, 124);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(58, 37);
            this.btn7.TabIndex = 6;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(75, 124);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(58, 37);
            this.btn8.TabIndex = 7;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(139, 124);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(58, 37);
            this.btn9.TabIndex = 8;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            // 
            // btnc
            // 
            this.btnc.Location = new System.Drawing.Point(11, 253);
            this.btnc.Name = "btnc";
            this.btnc.Size = new System.Drawing.Size(58, 37);
            this.btnc.TabIndex = 9;
            this.btnc.Text = "C";
            this.btnc.UseVisualStyleBackColor = true;
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(75, 253);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(58, 37);
            this.btn0.TabIndex = 10;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            // 
            // btnpunto
            // 
            this.btnpunto.Location = new System.Drawing.Point(139, 253);
            this.btnpunto.Name = "btnpunto";
            this.btnpunto.Size = new System.Drawing.Size(58, 37);
            this.btnpunto.TabIndex = 11;
            this.btnpunto.Text = ".";
            this.btnpunto.UseVisualStyleBackColor = true;
            // 
            // btnigual
            // 
            this.btnigual.Location = new System.Drawing.Point(203, 253);
            this.btnigual.Name = "btnigual";
            this.btnigual.Size = new System.Drawing.Size(58, 37);
            this.btnigual.TabIndex = 15;
            this.btnigual.Text = "=";
            this.btnigual.UseVisualStyleBackColor = true;
            // 
            // btnmenos
            // 
            this.btnmenos.Location = new System.Drawing.Point(203, 167);
            this.btnmenos.Name = "btnmenos";
            this.btnmenos.Size = new System.Drawing.Size(58, 37);
            this.btnmenos.TabIndex = 13;
            this.btnmenos.Text = "-";
            this.btnmenos.UseVisualStyleBackColor = true;
            // 
            // btnmas
            // 
            this.btnmas.Location = new System.Drawing.Point(203, 210);
            this.btnmas.Name = "btnmas";
            this.btnmas.Size = new System.Drawing.Size(58, 37);
            this.btnmas.TabIndex = 12;
            this.btnmas.Text = "+";
            this.btnmas.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(12, 74);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(250, 44);
            this.textBox1.TabIndex = 16;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(266, 39);
            this.label1.TabIndex = 17;
            this.label1.Text = "Calculator Plus";
            // 
            // btnpor
            // 
            this.btnpor.Location = new System.Drawing.Point(203, 124);
            this.btnpor.Name = "btnpor";
            this.btnpor.Size = new System.Drawing.Size(58, 37);
            this.btnpor.TabIndex = 18;
            this.btnpor.Text = "x";
            this.btnpor.UseVisualStyleBackColor = true;
            // 
            // Formularioprincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 302);
            this.Controls.Add(this.btnpor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnigual);
            this.Controls.Add(this.btnmenos);
            this.Controls.Add(this.btnmas);
            this.Controls.Add(this.btnpunto);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btnc);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Name = "Formularioprincipal";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btnc;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnpunto;
        private System.Windows.Forms.Button btnigual;
        private System.Windows.Forms.Button btnmenos;
        private System.Windows.Forms.Button btnmas;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnpor;
    }
}

