﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Promediodenotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double nota;
            double sumanotas = 0;

            if(txtAlumnos.Text.Length > 0){

                for(int Cantidad = 1;Cantidad <= int.Parse(txtAlumnos.Text);Cantidad++){

                    nota = Convert.ToDouble(Microsoft.VisualBasic.Interaction.InputBox("Ingrese la nota del alumno" + Cantidad, "Promedio notas","16",100,100));
                    sumanotas += nota;
                }

                txtPromedio.Text = (sumanotas / int.Parse(txtAlumnos.Text)).ToString();

            }





        }
    }
}
